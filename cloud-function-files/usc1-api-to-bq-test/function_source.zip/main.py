import functions_framework
import polars as pl
import pandas as pd
from sodapy import Socrata
import time
from datetime import datetime
from google.cloud import storage,bigquery
from pandas_gbq import to_gbq



@functions_framework.http
def hello_http(request):
    """HTTP Cloud Function.
    Args:
        request (flask.Request): The request object.
        <https://flask.palletsprojects.com/en/1.1.x/api/#incoming-request-data>
    Returns:
        The response text, or any set of values that can be turned into a
        Response object using `make_response`
        <https://flask.palletsprojects.com/en/1.1.x/api/#flask.make_response>.
    """
    request_json= request.get_json(silent=True)
    request_args = request.args
    print("name",request_json["name"])
    print("args",request_args)
    # if "name" in request_args:
    #     print("yaaas")
    # else:
    #     print("nope")

    client = Socrata("data.cityofnewyork.us", None)
    
    # x=10
    # print("sleeping seconds",x)
    # time.sleep(x)

    results = client.get("4b4i-vvec", limit=request_json["limit"],offset=request_json["offset_value"])
    results_df = pl.DataFrame(results)
    print(results_df.head(1))
    bucket_client = storage.Client()
    bucket = bucket_client.get_bucket(request_json["dest_bucket"])
    unq_postfix=datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    blob=bucket.blob(f"taxi_cab_data_{unq_postfix}.csv")
    csv_str = results_df.write_csv()
    blob.upload_from_string(csv_str)
    print("timestamp",unq_postfix)
    print(type(unq_postfix))
    results_df=results_df.with_columns(pl.lit(unq_postfix).alias("event_timestamp"))
    print(results_df.tail(5))

    write_to_bigquery(results_df,request_json["dataset_table"],request_json["project_id"])
    
    return "success"

    # Then do other things...
    
    
def write_to_bigquery(results_df,dataset_table,project_id):
    bq_client=bigquery.Client()
    print("schema",results_df.schema)
    pandas_df=results_df.to_pandas()

    #####
    job_config = bigquery.LoadJobConfig(
    # # table. The schema is used to assist in data type definitions.
    # schema=[
    #     # Specify the type of columns whose type cannot be auto-detected. For
    #     # example the "title" column uses pandas dtype "object", so its
    #     # data type is ambiguous.
    #     bigquery.SchemaField("title", bigquery.enums.SqlTypeNames.STRING),
    #     # Indexes are written if included in the schema by name.
    #     bigquery.SchemaField("wikidata_id", bigquery.enums.SqlTypeNames.STRING),
    # ],
    # Optionally, set the write disposition. BigQuery appends loaded rows
    # to an existing table by default, but with WRITE_TRUNCATE write
    # disposition it replaces the table with the loaded data.
    write_disposition="WRITE_TRUNCATE")
    ###





    job=bq_client.load_table_from_dataframe(pandas_df,dataset_table,job_config=job_config)
    job.result()
    print("done done done")


#json and command to trigger cf
#  -X POST https://api-to-cloud-storage-418010090109.us-central1.run.app \
# > -H "Authorization: bearer $(gcloud auth print-identity-token)" \
# > -H "Content-Type: application/json" \
# > -d '{ "name": "Developer", "limit": 100 , "offset_value": 100, "dest_bucket" : "a-d-b-data-pilot-1" , "project_id" : "proj-a-d-b-data-1", "dataset_table" : "PILOT_DATASET.test_a" }'
    

#{ "name": "Developer", "limit": 100 , "offset_value": 100, "dest_bucket" : "usc1-landing-archive" , "project_id" : "project-beta-000002", "dataset_table" : "BETA_LANDING.Landing_Table" }




